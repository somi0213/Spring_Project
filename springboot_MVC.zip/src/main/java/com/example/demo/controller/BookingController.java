
package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//import com.example.demo.model.Booking;

import com.example.demo.dao.BookingDao;
import com.example.demo.model.Booking;

@RestController
public class BookingController {

	@Autowired
	private BookingDao bookingDao;

	@PostMapping("/booking")
	@CrossOrigin(origins = "http://localhost:4200")
	public String booking(@RequestBody Booking booking) {

		System.out.println("inside post");
		System.out.println(booking.getUsername() + " " + booking.getPassword() + " " + booking.getEmail() + " "
				+ booking.getNumber()+" " + booking.getDate()+" "+booking.getTodate());

		bookingDao.save(booking);
		return "values inserted";
	}
		@DeleteMapping("del/{id}")
		@CrossOrigin(origins = "http://localhost:4200")
		public String delBooking(@PathVariable("id") int id) {

			bookingDao.deleteById(id);
			return "value deleted";
	}
}


