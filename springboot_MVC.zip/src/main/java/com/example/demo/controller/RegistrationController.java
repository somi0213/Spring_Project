package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.RegisterDao;
import com.example.demo.model.Register;

@RestController
public class RegistrationController {
	@Autowired
	private RegisterDao registerDao;

	@PostMapping("/register")
	@CrossOrigin(origins = "http://localhost:4200")
	public String Register(@RequestBody Register register) {

		System.out.println("inside post");
		System.out.println(register.getUsername() + " " + register.getPassword() + " " + register.getEmail() + " "
				+ register.getNumber());
		registerDao.save(register);
		return "values inserted";
	}
	
	/*
	 * @PostMapping("/register")
	 * 
	 * @CrossOrigin(origins = "http://localhost:4200")
	 */
	
	@PostMapping("/user")
	@CrossOrigin(origins = "http://localhost:4200")
	public Boolean validate(@RequestBody Register reg) {

		List<Register> list = (List<com.example.demo.model.Register>) registerDao.findAll();
		boolean isPresent = false;
		
		for (int i = 0; i < list.size(); i++) {
			
			if(reg.getUsername().equals(list.get(i).getUsername())) {
				
				if(reg.getPassword().equals(list.get(i).getPassword())) {
					
					 isPresent = true;
					
				}
				
			}
			
		}
		
		return isPresent;
		
	}
	
	
	
}
