//package com.example.demo.dao;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Repository;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.model.Booking;
//
//@Repository
//public interface BookingDao extends CrudRepository<Booking,Integer> {
//@Autowired
//
//
//public void getBooking(String Username, String Password, String Email, Integer Number) {
//	
//}
//	
//	 Booking save(Booking booking);
//	 
//}
package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import com.example.demo.model.Booking;

@Service
public interface BookingDao extends CrudRepository<Booking,Integer> {

}
