package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Travel;
//public interface TravelDao extends CrudRepository<Travel, Integer> {
//	
//}

public interface TravelDao extends CrudRepository<Travel,Integer> {

}